# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(simplexPivot src/simplexPivot.cpp)
set_property(TARGET simplexPivot PROPERTY CXX_STANDARD 11)
target_link_libraries(simplexPivot lionss pthread)

add_executable(selinux-relabel src/selinux-relabel.cpp)
set_property(TARGET selinux-relabel PROPERTY CXX_STANDARD 11)
target_link_libraries(selinux-relabel lionss pthread)

add_executable(quickcheckGen src/quickcheckGen.cpp)
set_property(TARGET quickcheckGen PROPERTY CXX_STANDARD 11)
target_link_libraries(quickcheckGen lionss pthread)

add_executable(redoc-bundle src/redoc-bundle.cpp)
set_property(TARGET redoc-bundle PROPERTY CXX_STANDARD 11)
target_link_libraries(redoc-bundle lionss pthread)

add_executable(HelmholtzSolve src/HelmholtzSolve.cpp)
set_property(TARGET HelmholtzSolve PROPERTY CXX_STANDARD 11)
target_link_libraries(HelmholtzSolve lionss pthread)

add_executable(preactSignals src/preactSignals.cpp)
set_property(TARGET preactSignals PROPERTY CXX_STANDARD 11)
target_link_libraries(preactSignals lionss pthread)

add_executable(duckdbprobe src/duckdbprobe.cpp)
set_property(TARGET duckdbprobe PROPERTY CXX_STANDARD 11)
target_link_libraries(duckdbprobe lionss pthread)

add_executable(rocksdbCompact src/rocksdbCompact.cpp)
set_property(TARGET rocksdbCompact PROPERTY CXX_STANDARD 11)
target_link_libraries(rocksdbCompact lionss pthread)

add_executable(webrtcDtls src/webrtcDtls.cpp)
set_property(TARGET webrtcDtls PROPERTY CXX_STANDARD 11)
target_link_libraries(webrtcDtls lionss pthread)

add_executable(sparrowhawk src/sparrowhawk.cpp)
set_property(TARGET sparrowhawk PROPERTY CXX_STANDARD 11)
target_link_libraries(sparrowhawk lionss pthread)

add_executable(hdr-tonemap src/hdr-tonemap.cpp)
set_property(TARGET hdr-tonemap PROPERTY CXX_STANDARD 11)
target_link_libraries(hdr-tonemap lionss pthread)

add_executable(matterCommission src/matterCommission.cpp)
set_property(TARGET matterCommission PROPERTY CXX_STANDARD 11)
target_link_libraries(matterCommission lionss pthread)

add_executable(saltmarsh src/saltmarsh.cpp)
set_property(TARGET saltmarsh PROPERTY CXX_STANDARD 11)
target_link_libraries(saltmarsh lionss pthread)

add_executable(tinwhistle src/tinwhistle.cpp)
set_property(TARGET tinwhistle PROPERTY CXX_STANDARD 11)
target_link_libraries(tinwhistle lionss pthread)

add_executable(amber-wave src/amber-wave.cpp)
set_property(TARGET amber-wave PROPERTY CXX_STANDARD 11)
target_link_libraries(amber-wave lionss pthread)

add_executable(cnv-segment src/cnv-segment.cpp)
set_property(TARGET cnv-segment PROPERTY CXX_STANDARD 11)
target_link_libraries(cnv-segment lionss pthread)

add_executable(frustumcull src/frustumcull.cpp)
set_property(TARGET frustumcull PROPERTY CXX_STANDARD 11)
target_link_libraries(frustumcull lionss pthread)

add_executable(glossary-check src/glossary-check.cpp)
set_property(TARGET glossary-check PROPERTY CXX_STANDARD 11)
target_link_libraries(glossary-check lionss pthread)

add_executable(Vp9Svc src/Vp9Svc.cpp)
set_property(TARGET Vp9Svc PROPERTY CXX_STANDARD 11)
target_link_libraries(Vp9Svc lionss pthread)

add_executable(rayon_splitmix src/rayon_splitmix.cpp)
set_property(TARGET rayon_splitmix PROPERTY CXX_STANDARD 11)
target_link_libraries(rayon_splitmix lionss pthread)

add_executable(Cindersmith src/Cindersmith.cpp)
set_property(TARGET Cindersmith PROPERTY CXX_STANDARD 11)
target_link_libraries(Cindersmith lionss pthread)

add_executable(wasi-preopen src/wasi-preopen.cpp)
set_property(TARGET wasi-preopen PROPERTY CXX_STANDARD 11)
target_link_libraries(wasi-preopen lionss pthread)

add_executable(timeTravelDebug src/timeTravelDebug.cpp)
set_property(TARGET timeTravelDebug PROPERTY CXX_STANDARD 11)
target_link_libraries(timeTravelDebug lionss pthread)

add_executable(apparmor_profile src/apparmor_profile.cpp)
set_property(TARGET apparmor_profile PROPERTY CXX_STANDARD 11)
target_link_libraries(apparmor_profile lionss pthread)

add_executable(relooperCfg src/relooperCfg.cpp)
set_property(TARGET relooperCfg PROPERTY CXX_STANDARD 11)
target_link_libraries(relooperCfg lionss pthread)

add_executable(nsga2_front src/nsga2_front.cpp)
set_property(TARGET nsga2_front PROPERTY CXX_STANDARD 11)
target_link_libraries(nsga2_front lionss pthread)

add_executable(anf-lower src/anf-lower.cpp)
set_property(TARGET anf-lower PROPERTY CXX_STANDARD 11)
target_link_libraries(anf-lower lionss pthread)

add_executable(fft-window-hann src/fft-window-hann.cpp)
set_property(TARGET fft-window-hann PROPERTY CXX_STANDARD 11)
target_link_libraries(fft-window-hann lionss pthread)

add_executable(sack_reneg src/sack_reneg.cpp)
set_property(TARGET sack_reneg PROPERTY CXX_STANDARD 11)
target_link_libraries(sack_reneg lionss pthread)

add_executable(unwind-fp src/unwind-fp.cpp)
set_property(TARGET unwind-fp PROPERTY CXX_STANDARD 11)
target_link_libraries(unwind-fp lionss pthread)

