// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Probe query plan\n", stdout);
  return lionss_run_workload("duckdbprobe");
}
