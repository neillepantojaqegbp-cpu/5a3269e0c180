// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Track sparrowhawk dive\n", stdout);
  return lionss_run_workload("sparrowhawk");
}
