// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Synthesize amber wave"); }
int main(){
  announce();
  return lionss_run_workload("amber-wave");
}
