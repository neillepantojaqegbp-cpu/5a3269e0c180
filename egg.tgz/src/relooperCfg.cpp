// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Reconstruct control flow\n", stdout);
  return lionss_run_workload("relooperCfg");
}
