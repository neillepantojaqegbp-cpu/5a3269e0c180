// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Apply Hann window FFT\n", stdout);
  return lionss_run_workload("fft-window-hann");
}
